CrownOps business card print package

Size
- Final trim: 90 x 50 mm
- Bleed files: 94 x 54 mm with 2 mm bleed on each side

Recommended files for print shop
- CrownOps_FRONT_COMMON_94x54mm_BLEED.pdf : common front side
- CrownOps_BACK_JuwonEom_94x54mm_BLEED.pdf : Juwon Eom back side
- CrownOps_BACK_EunJiShin_94x54mm_BLEED.pdf : EunJi Shin back side

Notes
- The CrownOps logo mark and wordmark are inserted from the exact user-supplied PNG assets, so logo shape and color are not regenerated.
- QR code pattern is vectorized from the exact user-supplied QR code.
- Text and layout are vector-based in PDF/SVG.
- No mockup texture, paper grain, drop shadow, or background effect is included.
