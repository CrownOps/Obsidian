CrownOps business card vector source package

Brand hierarchy:
- Product: CrownOps
- Company/team: paraegis
- Display: CrownOps by paraegis

Files:
- CrownOps_front.svg: shared front side
- CrownOps_back_JuwonEom.svg: Juwon Eom back side
- CrownOps_back_EunJiShin.svg: EunJi Shin back side
- CrownOps_business_cards_all.svg: 2x2 proof sheet
- crownops_qrcode.png: actual QR code embedded in SVG files

Card size:
- 90mm x 50mm

Main colors:
- Coral: #FF8E73
- Coral dark: #FF704F
- Charcoal: #2B2F35
- Gray: #BDBDBD

Notes:
- Text is editable SVG text.
- Logo mark is vector-drawn approximation based on the latest CrownOps symbol.
- QR is embedded as a PNG data URI for scannability.
- For print production, convert text to outlines after final proofreading.
